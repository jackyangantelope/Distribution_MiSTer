class DownloaderError(Exception): pass
