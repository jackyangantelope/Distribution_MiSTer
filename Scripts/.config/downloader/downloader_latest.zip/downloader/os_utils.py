import subprocess
from abc import ABC
class OsUtils(ABC):
    def sync(self) -> None:
        ""
    def reboot(self) -> None:
        ""
class LinuxOsUtils(OsUtils):
    def sync(self) -> None:
        subprocess.run(['sync'], shell=False, stderr=subprocess.STDOUT)
    def reboot(self) -> None:
        subprocess.run(['reboot', 'now'], shell=False, stderr=subprocess.STDOUT)
