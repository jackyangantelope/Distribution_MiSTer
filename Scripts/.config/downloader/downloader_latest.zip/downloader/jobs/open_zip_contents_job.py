from dataclasses import field, dataclass
from enum import IntEnum, auto, unique
from typing import Any, Optional
from downloader.config import ConfigDatabaseSection
from downloader.db_entity import DbEntity
from downloader.file_filter import FileFoldersHolder, Config
from downloader.job_system import Job, JobSystem
from downloader.jobs.transfer_job import TransferJob
from downloader.path_package import PathPackage
from downloader.local_store_wrapper import ReadOnlyStoreAdapter
@unique
class ZipKind(IntEnum):
    EXTRACT_ALL_CONTENTS = auto()
    EXTRACT_SINGLE_FILES = auto()
@dataclass(eq=False, order=False)
class OpenZipContentsJob(Job):
    type_id: int = field(init=False, default=JobSystem.get_job_type_id())
    db: DbEntity
    store: ReadOnlyStoreAdapter
    ini_description: ConfigDatabaseSection
    config: Config
    zip_id: str
    zip_kind: ZipKind
    zip_description: dict[str, Any]
    target_folder: Optional[PathPackage]
    total_amount_of_files_in_zip: int
    files_to_unzip: list[PathPackage]
    recipient_folders: list[PathPackage]
    transfer_job: TransferJob # Job & Transferrer @TODO: Python 3.10
    action_text: str
    zip_base_files_url: str
    filtered_data: FileFoldersHolder
    def retry_job(self): return self.transfer_job
    downloaded_files: list[PathPackage] = field(default_factory=list)
    validated_files: list[PathPackage] = field(default_factory=list)
    failed_files: list[PathPackage] = field(default_factory=list)
    directories_to_remove: list[PathPackage] = field(default_factory=list)
    files_to_remove: list[PathPackage] = field(default_factory=list)
