from dataclasses import field, dataclass
from typing import Any, Optional
from downloader.config import Config, ConfigDatabaseSection
from downloader.db_entity import DbEntity
from downloader.job_system import Job, JobSystem
from downloader.jobs.process_zip_index_job import ProcessZipIndexJob
from downloader.jobs.transfer_job import TransferJob
from downloader.local_store_wrapper import ReadOnlyStoreAdapter
@dataclass(eq=False, order=False)
class OpenZipSummaryJob(Job):
    type_id: int = field(init=False, default=JobSystem.get_job_type_id())
    db: DbEntity
    store: ReadOnlyStoreAdapter
    zip_id: str
    ini_description: ConfigDatabaseSection
    zip_description: dict[str, Any]
    config: Config
    transfer_job: TransferJob # Job & Transferrer  @TODO: Python 3.10
    backup: Optional[ProcessZipIndexJob]
    def retry_job(self) -> Optional[Job]:
        return self.transfer_job  # type: ignore[return-value]
    def backup_job(self) -> Optional[Job]:
        return self.backup
