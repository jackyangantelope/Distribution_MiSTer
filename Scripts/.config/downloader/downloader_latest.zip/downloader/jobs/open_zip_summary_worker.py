from downloader.db_entity import check_zip_summary, ZipIndexEntity
from downloader.file_system import FileSystem
from downloader.job_system import WorkerResult, ProgressReporter
from downloader.jobs.jobs_factory import make_process_zip_index_job
from downloader.jobs.open_zip_summary_job import OpenZipSummaryJob
from downloader.jobs.worker_context import DownloaderWorker, FailCtx
from downloader.logger import Logger
class OpenZipSummaryWorker(DownloaderWorker):
    def __init__(self, file_system: FileSystem, logger: Logger, progress_reporter: ProgressReporter, fail_ctx: FailCtx) -> None:
        self._file_system = file_system
        self._logger = logger
        self._progress_reporter = progress_reporter
        self._fail_ctx = fail_ctx
    def job_type_id(self) -> int: return OpenZipSummaryJob.type_id
    def reporter(self): return self._progress_reporter
    def operate_on(self, job: OpenZipSummaryJob) -> WorkerResult:  # type: ignore[override]
        try:
            db, zip_id = job.db, job.zip_id
            self._logger.bench('OpenZipSummaryWorker load dict: ', db.db_id, zip_id)
            summary = self._file_system.load_dict_from_transfer(job.transfer_job.source, job.transfer_job.transfer())  # type: ignore[union-attr]
            check_zip_summary(summary, db.db_id, zip_id)
            base_files_url = db.base_files_url
            if 'base_files_url' in job.zip_description:
                base_files_url = job.zip_description['base_files_url']
            self._logger.bench('OpenZipSummaryWorker zip index entity instantiation: ', db.db_id, zip_id)
            zip_index = ZipIndexEntity(files=summary['files'],
                                       folders=summary['folders'],
                                       base_files_url=summary.get('base_files_url', base_files_url),
                                       version=summary.get('v', 0),
                                       description=job.zip_description)
            if zip_index.needs_migration():
                self._logger.bench('OpenZipSummaryWorker migrating zip index entity: ', db.db_id, zip_id)
                error = zip_index.migrate(db.db_id)
                if error is not None:
                    self._fail_ctx.swallow_error(error)
                    return [], error
            self._logger.bench('OpenZipSummaryWorker done: ', db.db_id, zip_id)
            return [make_process_zip_index_job(
                zip_id=zip_id,
                zip_index=zip_index,
                config=job.config,
                db=db,
                ini_description=job.ini_description,
                store=job.store,
                has_new_zip_summary=True
            )], None
        except Exception as e:
            self._fail_ctx.swallow_error(e)
            return [], e
