import datetime
import tempfile
import sys
import time
import traceback
from typing import Any, Optional, Protocol, TextIO, cast
from pathlib import Path
import json
from downloader.config import Config, Environment
class Logger(Protocol):
    def print(self, *args: Any, sep: str='', end: str='\n', file: TextIO=sys.stdout, flush: bool=True) -> None: ""
    def debug(self, *args: Any, sep: str='', end: str='\n', flush: bool=True) -> None: ""
    def bench(self, *args: Any) -> None: ""
class PrintLogger(Logger):
    def print(self, *args: Any, sep: str='', end: str='\n', file: TextIO=sys.stdout, flush: bool=True) -> None:
        _do_print(*args, sep=sep, end=end, file=file, flush=flush)
    def debug(self, *args: Any, sep: str='', end: str='\n', flush: bool=True) -> None:
        _do_print("DEBUG| ", *args, sep=sep, end=end, file=sys.stdout, flush=flush)
    def bench(self, *args: Any) -> None:
        _do_print(*args, sep='', end='\n', file=sys.stdout, flush=True)
def _do_print(*args: Any, sep: str, end: str, file: TextIO, flush: bool) -> None:
    try:
        print(*args, sep=sep, end=end, file=file, flush=flush)
    except UnicodeEncodeError:
        pack = []
        for a in args:
            pack.append(a.encode('utf8', 'surrogateescape'))
        print(*pack, sep=sep, end=end, file=file, flush=flush)
    except BaseException as error:
        print('An unknown exception occurred during logging: %s' % str(error))
class OffLogger(Logger):
    def print(self, *args: Any, sep: str='', end: str='\n', file: TextIO=sys.stdout, flush: bool=False) -> None: pass
    def debug(self, *args: Any, sep: str='', end: str='\n', file: TextIO=sys.stdout, flush: bool=False) -> None: pass
    def bench(self, *args: Any) -> None: pass
class FilelogSaver(Protocol):
    def rotate_logs(self) -> None: pass
    def set_temp_log_name(self, name: str) -> None: pass
    def save_log_from_tmp(self, tmp_logfile: str) -> None: pass
class FilelogManager(Protocol):
    def finalize(self) -> None: pass
    def set_local_repository(self, local_repository: FilelogSaver) -> None: pass
class FileLogger(Logger, FilelogManager):
    def __init__(self) -> None:
        self._logfile: Optional[TextIO] = cast(TextIO, tempfile.NamedTemporaryFile('w', delete=False))
        self._local_repository: Optional[FilelogSaver] = None
    def finalize(self) -> None:
        if self._logfile is None:
            return
        if self._local_repository is None:
            self.print('Log saved in temp file: ' + self._logfile.name)
        if self._local_repository is not None:
            self._local_repository.rotate_logs()
        self._logfile.close()
        if self._local_repository is not None:
            self._local_repository.save_log_from_tmp(self._logfile.name)
        self._logfile = None
    def set_local_repository(self, local_repository: FilelogSaver) -> None:
        self._local_repository = local_repository
        if self._logfile is not None:
            self._local_repository.set_temp_log_name(self._logfile.name)
    def print(self, *args: Any, sep: str='', end: str='\n', file: TextIO=sys.stdout, flush: bool=True) -> None:
        self._do_print_in_file(*args, sep=sep, end=end, flush=flush)
    def debug(self, *args: Any, sep: str='', end: str='\n', flush: bool=True) -> None:
        self._do_print_in_file("DEBUG| ", *args, sep=sep, end=end, flush=flush)
    def bench(self, *args: Any) -> None:
        self._do_print_in_file(*args, sep='', end='\n', flush=False)
    def _do_print_in_file(self, *args: Any, sep: str, end: str, flush: bool) -> None:
        if self._logfile is not None:
            _do_print(*args, sep=sep, end=end, file=self._logfile, flush=flush)
class ConfigLogManager(Protocol):
    def configure(self, config: Config) -> None: pass
class TopLogger(Logger, ConfigLogManager):
    def __init__(self, print_logger: PrintLogger, file_logger: FileLogger, verbose_mode: bool, bench_mode: bool, start_time: float) -> None:
        self.print_logger = print_logger
        self.file_logger = file_logger
        self._verbose_mode = verbose_mode
        self._bench_mode = bench_mode
        self._start_time = start_time
        self._received_exception = False
    @staticmethod
    def for_main(env: Environment, start_time: float) -> 'TopLogger':
        verbose_mode = False
        bench_mode = False
        if env['LOGLEVEL'] != '':
            if 'info' in env['LOGLEVEL']:
                verbose_mode = False
            if 'debug' in env['LOGLEVEL']:
                verbose_mode = True
            bench_mode = 'bench' in env['LOGLEVEL']
        return TopLogger(PrintLogger(), FileLogger(), verbose_mode, bench_mode, start_time)
    def configure(self, config: Config) -> None:
        self._bench_mode = config['bench']
        self._verbose_mode = config['verbose']
        config_msg = _create_config_msg(config)
        if self._verbose_mode:
            self.debug(config_msg)
        else:
            self.file_logger.debug(config_msg)
    def print(self, *args: Any, sep: str='', end: str='\n', file: TextIO=sys.stdout, flush: bool=False) -> None:
        self.print_logger.print(*args, sep=sep, end=end, file=file, flush=flush)
        self.file_logger.print(*args, sep=sep, end=end, file=file, flush=flush)
    def debug(self, *args: Any, sep: str='', end: str='\n', flush: bool=False) -> None:
        if self._verbose_mode is False and self._received_exception is False:
            if any(isinstance(a, BaseException) for a in args):
                self._received_exception = True
            else:
                return
        trans_args = _transform_debug_args(args)
        if self._verbose_mode:
            self.print_logger.debug(*trans_args, sep=sep, end=end, flush=flush)
        self.file_logger.debug(*trans_args, sep=sep, end=end, flush=flush)
    def bench(self, *args: Any) -> None:
        if not self._bench_mode:
            return
        bench_header = f'BENCH {time_str(self._start_time)}| '
        self.print_logger.bench(bench_header, *args)
        self.file_logger.bench(bench_header, *args)
def _create_config_msg(config: Config) -> str:
    try:
        return 'Config: ' + json.dumps(
            config,
            default=lambda o: str(o) if isinstance(o, Path) else o.__dict__,
            indent=4 if config['verbose'] else None,
            separators = None if config['verbose'] else (",", ":")
        )
    except Exception:
        return 'WARNING: Could not create message from config.'
def _transform_debug_args(args: tuple[Any, ...]) -> list[str]:
    exception_msgs: list[str] = []
    rest_args: list[str] = []
    interp_count = 0
    interp_main = ''
    interp_subs: list[str] = []
    for a in args:
        if isinstance(a, Exception):
            exception_msgs.append(_format_ex(a))
            continue
        if interp_count > 1:
            interp_subs.append(str(a))
            interp_count -= 1
        elif interp_count == 1:
            try:
                rest_args.append(interp_main % (*interp_subs, str(a)))
            except Exception as e:
                exception_msgs.append(_format_ex(e))
                rest_args.extend([interp_main, *interp_subs, str(a)])
            interp_subs = []
            interp_count = 0
            interp_main = ''
        elif isinstance(a, str) and (interp_count := a.count('%s')) > 0:
            interp_main = a
        else:
            rest_args.append(str(a))
    return [*rest_args, *exception_msgs]
def _format_ex(e: BaseException) -> str:
    exception_msg = ''.join(traceback.TracebackException.from_exception(e).format())
    padding = ' ' * 4
    while e.__cause__ is not None:
        e = e.__cause__
        exception_msg += padding + 'CAUSE: ' + padding.join(traceback.TracebackException.from_exception(e).format())
        padding += ' ' * 4
    return exception_msg
class DebugOnlyLoggerDecorator(Logger):
    def __init__(self, decorated_logger: Logger) -> None:
        self._decorated_logger = decorated_logger
    def print(self, *args: Any, sep: str='', end: str='\n', file: TextIO=sys.stdout, flush: bool=True) -> None:
        ""
        self._decorated_logger.debug(*args, sep=sep, end=end, flush=flush)
    def debug(self, *args: Any, sep: str='', end: str='\n', flush: bool=True) -> None:
        self._decorated_logger.debug(*args, sep=sep, end=end, flush=flush)
    def bench(self, *args: Any) -> None:
        self._decorated_logger.bench(*args)
def time_str(start_time: float) -> str:
    return str(datetime.timedelta(seconds=time.monotonic() - start_time))[0:-3]
