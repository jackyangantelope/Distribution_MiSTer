from downloader.store_migrator import MigrationBase
class MigrationV6(MigrationBase):
    version = 6
    def migrate(self, local_store) -> None:
        ""
        ""
        pass
