from downloader.config import Config
from downloader.constants import MEDIA_FAT
from downloader.store_migrator import MigrationBase
class MigrationV5(MigrationBase):
    def __init__(self, config: Config) -> None:
        self._config = config
    version = 5
    def migrate(self, local_store) -> None:
        ""
        try:
            from pathlib import Path
            mister_old = Path(self._config.get('base_system_path', MEDIA_FAT)) / 'Scripts/.config/downloader/MiSTer.old'
            if mister_old.is_file():
                mister_old.unlink(missing_ok=True)
        except Exception as e:
            print(e)
