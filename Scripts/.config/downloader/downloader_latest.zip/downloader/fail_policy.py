from enum import Enum, auto
class FailPolicy(Enum):
    FAIL_FAST = auto()
    FAULT_TOLERANT = auto()
    FAULT_TOLERANT_ON_CUSTOM_DOWNLOADER_ERRORS = auto()
