import ipaddress
from dataclasses import dataclass
from typing import Dict, Any, Final, List, Optional
from urllib.parse import urlparse
from downloader.constants import FILE_MiSTer, FILE_menu_rbf, FILE_MiSTer_ini, FILE_MiSTer_alt_ini, \
    FILE_downloader_launcher_script, FILE_MiSTer_alt_3_ini, FILE_MiSTer_alt_1_ini, FILE_MiSTer_alt_2_ini, \
    FILE_MiSTer_new, FOLDER_linux, FOLDER_saves, FOLDER_savestates, FOLDER_screenshots, FILE_PDFViewer, FILE_lesskey, \
    FILE_glow, FOLDER_gamecontrollerdb, FILE_gamecontrollerdb, DISTRIBUTION_MISTER_DB_ID, FILE_gamecontrollerdb_user, \
    FILE_yc_txt, DATABASE_LATEST_SUPPORTED_VERSION
from downloader.db_options import DbOptions
from downloader.error import DownloaderError
from downloader.path_package import PathPackage
class DbEntity:
    def __init__(self, db_props: Any, section: str) -> None:
        if not isinstance(db_props, dict):
            raise DbEntityValidationException(f'ERROR: Database "{section}" has improper format. The database maintainer should fix this.')
        if 'db_id' not in db_props: raise DbEntityValidationException(f'ERROR: Database "{section}" needs a "db_id" field. The database maintainer should fix this.')
        if 'files' not in db_props: raise DbEntityValidationException(f'ERROR: Database "{section}" needs a "files" field. The database maintainer should fix this.')
        if 'folders' not in db_props: raise DbEntityValidationException(f'ERROR: Database "{section}" needs a "folders" field. The database maintainer should fix this.')
        if 'timestamp' not in db_props: raise DbEntityValidationException(f'ERROR: Database "{section}" needs a "timestamp" field. The database maintainer should fix this.')
        self.version: int = db_props.get('v', 0)
        if not isinstance(self.version, int) or self.version < 0: raise DbEntityValidationException(f'ERROR: Database "{section}" needs a valid "v" field. The database maintainer should fix this.')
        self.db_id: str = str(db_props['db_id']).lower()
        if self.db_id != section.lower(): raise DbEntityValidationException(f'ERROR: Section "{section}" does not match database id "{self.db_id}". Fix your INI file.')
        self.timestamp: int = db_props['timestamp']
        if not isinstance(self.timestamp, int): raise DbEntityValidationException(f'ERROR: Database "{section}" needs a valid "timestamp" field. The database maintainer should fix this.')
        self.files: Dict[str, Any] = db_props['files']
        if not isinstance(self.files, dict): raise DbEntityValidationException(f'ERROR: Database "{section}" needs a valid "files" field. The database maintainer should fix this.')
        self.folders: Dict[str, Any] = db_props['folders']
        if not isinstance(self.folders, dict): raise DbEntityValidationException(f'ERROR: Database "{section}" needs a valid "folders" field. The database maintainer should fix this.')
        self.zips: Dict[str, Any] = db_props.get('zips', {})
        if not isinstance(self.zips, dict): raise DbEntityValidationException(f'ERROR: Database "{section}" needs a valid "zips" field. The database maintainer should fix this.')
        self.base_files_url: str = db_props.get('base_files_url', '')
        if not isinstance(self.base_files_url, str): raise DbEntityValidationException(f'ERROR: Database "{section}" needs a valid "base_files_url" field. The database maintainer should fix this.')
        self.tag_dictionary: Dict[str, int] = db_props.get('tag_dictionary', {})
        if not isinstance(self.tag_dictionary, dict): raise DbEntityValidationException(f'ERROR: Database "{section}" needs a valid "tag_dictionary" field. The database maintainer should fix this.')
        self.linux: Optional[Dict[str, Any]] = db_props.get('linux', None)
        if self.linux is not None and not isinstance(self.linux, dict): raise DbEntityValidationException(f'ERROR: Database "{section}" needs a valid "linux" field. The database maintainer should fix this.')
        self.header: List[str] = db_props.get('header', [])
        if not isinstance(self.header, list): raise DbEntityValidationException(f'ERROR: Database "{section}" needs a valid "header" field. The database maintainer should fix this.')
        self.default_options: DbOptions = DbOptions(db_props.get('default_options', None) or {})
        _fix_folders(self.folders)
    def extract_props(self) -> dict[str, Any]:  # pragma: no cover
        result = self.__dict__.copy()
        result['default_options'] = result['default_options'].unwrap_props()
        if result['linux'] is None:
            result.pop('linux')
        if result['header'] is None:
            result.pop('header')
        return result
    def needs_migration(self) -> bool:
        return self.version != DATABASE_LATEST_SUPPORTED_VERSION
    def migrate(self) -> Optional[Exception]:
        if self.version == 0:
            migrate_v0(self.files, self.folders)
            for zip_desc in self.zips.values():
                if 'target_folder_path' in zip_desc and zip_desc['target_folder_path'][0] == '|':
                    zip_desc['target_folder_path'] = zip_desc['target_folder_path'][1:]
                    zip_desc['path'] = 'pext'
                if 'internal_summary' not in zip_desc:
                    continue
                zip_index = zip_desc['internal_summary']
                migrate_v0(zip_index.get('files', {}), zip_index.get('folders', {}))
            self.version += 1
        if self.version == DATABASE_LATEST_SUPPORTED_VERSION:
            return None
        return DbVersionUnsupportedException(
            f'ERROR: Database "{self.db_id}" version {self.version} requires a newer Downloader'
            f'(current one supports up to v{DATABASE_LATEST_SUPPORTED_VERSION}).'
            'Update Downloader or configure "db_url" to point to a supported database version.'
        )
@dataclass
class ZipIndexEntity:
    files: dict[str, Any]
    folders: dict[str, Any]
    base_files_url: str
    version: int
    description: dict[str, Any]
    def __post_init__(self) -> None:
        _fix_zip(self)
    def needs_migration(self) -> bool:
        return self.version != DATABASE_LATEST_SUPPORTED_VERSION
    def migrate(self, db_id: str) -> Optional[Exception]:
        if self.version == 0:
            migrate_v0(self.files, self.folders)
            self.version += 1
        if self.version == DATABASE_LATEST_SUPPORTED_VERSION:
            return None
        return DbVersionUnsupportedException(
            f'ERROR: Database "{db_id}" version {self.version} requires a newer Downloader'
            f' (current one supports up to v{DATABASE_LATEST_SUPPORTED_VERSION}).'
            ' Update Downloader or configure "db_url" to point to a supported database version.'
        )
def check_zip_description(desc: dict[str, Any], db_id: str, zip_id: str) -> None:
    if 'kind' not in desc or desc['kind'] not in ('extract_all_contents', 'extract_single_files'):
        raise DbEntityValidationException(f'ERROR: Invalid zip "{zip_id}" for database: {db_id}. It needs to contain a valid "kind" field. The database maintainer should fix this.')
    if 'description' not in desc or not isinstance(desc['description'], str):
        raise DbEntityValidationException(f'ERROR: Invalid zip "{zip_id}" for database: {db_id}. It needs to contain a valid "description" field. The database maintainer should fix this.')
    if 'contents_file' not in desc or not isinstance(desc['contents_file'], dict):
        raise DbEntityValidationException(f'ERROR: Invalid zip "{zip_id}" for database: {db_id}. It needs to contain a valid "contents_file" field. The database maintainer should fix this.')
    if ('internal_summary' not in desc or not isinstance(desc['internal_summary'], dict)) and ('summary_file' not in desc or not isinstance(desc['summary_file'], dict)):
        raise DbEntityValidationException(f'ERROR: Invalid zip "{zip_id}" for database: {db_id}. It needs to contain a valid summary field. The database maintainer should fix this.')
    if 'hash' not in desc['contents_file'] or not isinstance(desc['contents_file']['hash'], str):
        raise DbEntityValidationException(f'ERROR: Invalid zip "{zip_id}" for database: {db_id}. Contents file needs a valid hash. The database maintainer should fix this.')
    if 'size' not in desc['contents_file'] or not isinstance(desc['contents_file']['size'], int):
        raise DbEntityValidationException(f'ERROR: Invalid zip "{zip_id}" for database: {db_id}. Contents file needs a valid size. The database maintainer should fix this.')
    if 'url' not in desc['contents_file'] or not is_url_valid(desc['contents_file']['url']):
        raise DbEntityValidationException(f'ERROR: Invalid zip "{zip_id}" for database: {db_id}. Contents file needs a valid url. The database maintainer should fix this.')
    if 'internal_summary' in desc:
        check_zip_summary(desc['internal_summary'], db_id, zip_id)
    if 'summary_file' in desc:
        if 'hash' not in desc['summary_file'] or not isinstance(desc['summary_file']['hash'], str):
            raise DbEntityValidationException(f'ERROR: Invalid zip "{zip_id}" for database: {db_id}. Summary file needs a valid hash. The database maintainer should fix this.')
        if 'size' not in desc['summary_file'] or not isinstance(desc['summary_file']['size'], int):
            raise DbEntityValidationException(f'ERROR: Invalid zip "{zip_id}" for database: {db_id}. Summary file needs a valid size. The database maintainer should fix this.')
        if 'url' not in desc['summary_file'] or not is_url_valid(desc['summary_file']['url']):
            raise DbEntityValidationException(f'ERROR: Invalid zip "{zip_id}" for database: {db_id}. Summary file needs a valid url. The database maintainer should fix this.')
    if 'path' in desc and desc['path'] != 'pext':
        del desc['path']
def check_zip_summary(summary: dict[str, Any], db_id: str, zip_id: str) -> None:
    if 'files' not in summary or not isinstance(summary['files'], dict):
        raise DbEntityValidationException(f'ERROR: Invalid zip summary "{zip_id}" for database: {db_id}. Summary needs valid files dictionary. The database maintainer should fix this.')
    if 'folders' not in summary or not isinstance(summary['folders'], dict):
        raise DbEntityValidationException(f'ERROR: Invalid zip summary "{zip_id}" for database: {db_id}. Summary needs valid folders dictionary. The database maintainer should fix this.')
def check_no_url_files(files: list[PathPackage], db_id: str) -> None:
    if len(files) == 0: return
    for file_pkg in files:
        file_path, file_description = file_pkg.rel_path, file_pkg.description
        parts = _validate_and_extract_parts_from_path(db_id, file_path)
        if parts[0] in folders_with_non_overridable_files and file_description.get('overwrite', True):
            raise DbEntityValidationException(f'ERROR: Invalid file "{file_path}" for database: {db_id}. Can not override in that folder. The database maintainer should fix this.')
        if 'hash' not in file_description or not isinstance(file_description['hash'], str): raise DbEntityValidationException(f'ERROR: Invalid file "{file_path}" for database: {db_id}. File needs a valid hash. The database maintainer should fix this.')
        if 'size' not in file_description or not isinstance(file_description['size'], int): raise DbEntityValidationException(f'ERROR: Invalid file "{file_path}" for database: {db_id}. File needs a valid size. The database maintainer should fix this.')
def check_file_pkg(file_pkg: PathPackage, db_id: str, url: Optional[str], /) -> None:
    file_path, file_description = file_pkg.rel_path, file_pkg.description
    if not is_url_valid(url or file_description.get('url', None)):
        raise DbEntityValidationException(f'ERROR: Invalid file "{file_path}" for database: {db_id}. Invalid url "{url}". The database maintainer should fix this.')
    parts = _validate_and_extract_parts_from_path(db_id, file_path)
    if parts[0] in folders_with_non_overridable_files and file_description.get('overwrite', True):
        raise DbEntityValidationException(f'ERROR: Invalid file "{file_path}" for database: {db_id}. Can not override in that folder. The database maintainer should fix this.')
    if 'hash' not in file_description or not isinstance(file_description['hash'], str): raise DbEntityValidationException(f'ERROR: Invalid file "{file_path}" for database: {db_id}. File needs a valid hash. The database maintainer should fix this.')
    if 'size' not in file_description or not isinstance(file_description['size'], int): raise DbEntityValidationException(f'ERROR: Invalid file "{file_path}" for database: {db_id}. File needs a valid size. The database maintainer should fix this.')
def is_url_valid(url: str) -> bool:
    try:
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https"):
            return False
        if any(c in url for c in ("\r", "\n")):
            return False
        hostname = parsed.hostname
        if not hostname:
            return False
        if hostname.lower() == "localhost":
            return False
        try:
            ip = ipaddress.ip_address(hostname)
            if ip.is_private or ip.is_loopback:
                return False
        except ValueError:
            pass
        return True
    except:
        return False
def check_folder_paths(folders: list[str], db_id: str) -> None:
    if len(folders) == 0: return
    for folder_path in folders:
        _validate_and_extract_parts_from_path(db_id, folder_path)
def _fix_folders(folders: dict[str, Any]) -> None:
    if not folders: return
    to_fix = [folder_path for folder_path in folders if folder_path.endswith('/')]
    for folder_path in to_fix:
        folders[folder_path[:-1]] = folders.pop(folder_path)
def _fix_zip(zip_index: ZipIndexEntity) -> None:
    zip_desc = zip_index.description
    if 'target_folder_path' in zip_desc and len(zip_desc['target_folder_path']) > 0 and zip_desc['target_folder_path'][0] == '|':
        zip_desc['target_folder_path'] = zip_desc['target_folder_path'][1:]
        zip_desc['path'] = 'pext'
    if zip_desc['kind'] == 'extract_all_contents':
        if zip_desc.get('path', '') == 'pext':
            for d in zip_index.files.values(): add_pext(d)
            for d in zip_index.folders.values(): add_pext(d)
        else:
            for d in zip_index.files.values(): del_pext(d)
            for d in zip_index.folders.values(): del_pext(d)
def add_pext(desc: dict[str, Any]) -> dict[str, Any]:
    if 'path' in desc and desc['path'] == 'pext':
        return desc
    desc['path'] = 'pext'
    return desc
def del_pext(desc: dict[str, Any]) -> dict[str, Any]:
    if 'path' in desc and desc['path'] == 'pext':
        del desc['path']
    return desc
def _validate_and_extract_parts_from_path(db_id: str, path: str) -> list[str]:
    if not isinstance(path, str):
        raise DbEntityValidationException(f'ERROR: Invalid file "{path}" for database: {db_id}. Path should be a string. The database maintainer should fix this.')
    if path == '' or path[0] == '/' or path[0] == '.' or path[0] == '\\':
        raise DbEntityValidationException(f'ERROR: Invalid file "{path}" for database: {db_id}. Path should be valid. The database maintainer should fix this.')
    lower_path = path.lower()
    parts = lower_path.split('/')
    if lower_path in exceptional_paths:
        return parts
    if db_id == DISTRIBUTION_MISTER_DB_ID and lower_path in distribution_mister_exceptional_paths:
        return parts
    if lower_path in invalid_paths:
        raise DbEntityValidationException(f'ERROR: Invalid file "{path}" for database: {db_id}. Path should not be illegal. The database maintainer should fix this.')
    if db_id != DISTRIBUTION_MISTER_DB_ID and lower_path in no_distribution_mister_invalid_paths:
        raise DbEntityValidationException(f'ERROR: Invalid file "{path}" for database: {db_id}. Path should only valid for distribution_mister. The database maintainer should fix this.')
    if '..' in parts or len(parts) == 0 or parts[0] in invalid_root_folders:
        raise DbEntityValidationException(f'ERROR: Invalid file "{path}" for database: {db_id}. Path can\'t contain root folders. The database maintainer should fix this.')
    return parts
no_distribution_mister_invalid_paths: Final[tuple[str, ...]] = tuple(item.lower() for item in [FILE_MiSTer, FILE_menu_rbf, FILE_downloader_launcher_script])
invalid_paths: Final[tuple[str, ...]] = tuple(item.lower() for item in [FILE_MiSTer_ini, FILE_MiSTer_alt_ini, FILE_MiSTer_alt_1_ini, FILE_MiSTer_alt_2_ini, FILE_MiSTer_alt_3_ini, FILE_MiSTer_new])
invalid_root_folders: Final[tuple[str, ...]] = tuple(item.lower() for item in [FOLDER_linux, FOLDER_screenshots, FOLDER_savestates])
folders_with_non_overridable_files: Final[tuple[str, ...]] = tuple(item.lower() for item in [FOLDER_saves])
exceptional_paths: Final[tuple[str, ...]] = tuple(item.lower() for item in [FOLDER_linux, FOLDER_gamecontrollerdb, FILE_gamecontrollerdb, FILE_gamecontrollerdb_user, FILE_yc_txt])
distribution_mister_exceptional_paths: Final[tuple[str, ...]] = tuple(item.lower() for item in [FILE_PDFViewer, FILE_lesskey, FILE_glow])
class DbEntityValidationException(DownloaderError): pass
class DbVersionUnsupportedException(DownloaderError): pass
def migrate_v0(files: dict[str, Any], folders: dict[str, Any]) -> None:
    fix_old_pext(files)
    fix_old_pext(folders)
def fix_old_pext(entries: dict[str, Any]) -> None:
    old_pext_entries = {f[1:]: add_pext(d) for f, d in entries.items() if f[0] == '|'}
    if len(old_pext_entries) > 0:
        non_old_pext_entries = {f: d for f, d in entries.items() if f[0] != '|'}
        entries.clear()
        entries.update(non_old_pext_entries)
        entries.update(old_pext_entries)
